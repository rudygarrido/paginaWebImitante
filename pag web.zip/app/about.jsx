import React from 'react'

const styles={
	about:{
		background: '#CB7D30',
		color: 'white',
		height: '500'
	},
	text: {
		width: '80%',
		marginLeft: '12%',
		paddingTop: '13%',
		fontSize: '25px',
		marginTop: '0%'
	},
	textAbout:{
		fontWeight: 'bold',
		marginTop: '0%'
	}
	
}

export default class About extends React.Component{
	render(){
			return(
				<div id="about" style={styles.about}>
					
					<p style={styles.text}>
						<p style={styles.textAbout}>About</p> <br/>
						Caliber Capital was founded by <u>Danny York</u> and <u>Mac McCall</u>, 
						former founders and managers of  a large commercial real 
						estate firm based in Tampa, FL. Through years of cultivated 
						relationships    with owners, brokers, and tenants of commercial 
						retail development projects,  Caliber Capital has become a trusted 
						advisor and partner for investors. 
					</p>
				</div>
			
			)
		
		
		
	}
}