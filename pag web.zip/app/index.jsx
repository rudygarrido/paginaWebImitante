import React from 'react'
import {render} from 'react-dom'
import Bienvenida from './bienvenida.jsx'
import About from './about.jsx'
class App extends React.Component {
		render(){
				
				return <div><Bienvenida/><About/></div>
				
		}
}



render(<App/>, document.getElementById('app'))
