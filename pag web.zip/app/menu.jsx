import React from 'react'
import logo from './caliber-capital.v1.svg'
const styles={
	back:{

	},
	logo: {
		float: 'left',
		width: '290',
		marginLeft: '10%',
		paddingTop: '2%'
	},
	menuItem: {
		float: 'right',
		color: 'white',
		marginLeft: '0.6%',
		marginRight: '2.3%',
		marginTop: '5%',
		fontSize: '18px',
		fontWeight: 'bold',
		letterSpacing: '1px'
	}
}

export default class Menu extends React.Component{
	render(){
		return (
			<div>
				<div style={styles.logo} dangerouslySetInnerHTML={{__html:logo}}></div> 
				<div style={styles.menuItem}>Contact Us </div>
				<div style={styles.menuItem}>Client Login </div>
				<div style={styles.menuItem}>Portofolio </div>
				<div style={styles.menuItem}>Strategy + Services </div>
				<div style={styles.menuItem}>Our Team </div>
			</div>
		
		)
	}
	
}