import React from 'react'
import logo from './caliber-capital.v1.svg'
import Menu from './menu.jsx'


const styles={
	text:{
		color: 'white',
		marginLeft: '12%',
		paddingTop: '17%',
		paddingBottom: '3%',
		marginTop: '0%',
		marginBottom: '0%',
		fontSize: '30px'
	},
	boton:{
		
		width: '50px',
		height: '30px',
		backgroundSize: 'cover',
		backgroundRepeat: 'no-repeat',
		paddingBottom: '3%',
		border: 'none',
		marginLeft: '47%',
		marginBottom: '0%',
		display: 'block',
		marginTop: '9%'
	},
	todo:{
		backgroundImage: 'url("bricks.jpg")',
		backgroundSize: 'cover',
		backgroundRepeat: 'no-repeat',
		maringBottom: '0%'
		
	},
	textTittle:{
		fontWeight: 'bold',
		marginTop: '0%'
	}
}

export default class Bienvenida extends React.Component{
	
	constructor(props){
		super(props)
		this.state = {
			pos : 1
		}
	}
	
	moveScreen(){
		if(this.state.pos == 0){
			this.setState({
				pos: 500
			})
		}else{
			this.setState({
				pos: 0
			})
		}
	}
	
	render(){
		console.log(window.location)
		window.scrollTo(0,this.state.pos)
		return (
			<div style={styles.todo}>
			<Menu/>
			<p style={styles.text}>
			<div style={styles.textTittle}>A Trusted Advisor and Partner </div> <br/>
			Caliber Capital is a privately funded real estate company focused on <br/> developing and acquiring properties throughout the country that can <br/> deliver optimal returns with limited risk.
			</p>
			<img src="https://www.caliber-capital.com/img/icons/arrow-down.v1.png" onClick={this.moveScreen.bind(this)} style={styles.boton}></img>
			</div>
		)
	}
}